# maple
IT's a theme about ghost

支持v1.x